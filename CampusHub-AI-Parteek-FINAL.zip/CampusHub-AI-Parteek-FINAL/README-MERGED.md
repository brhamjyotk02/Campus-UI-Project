# CampusHub AI — CSE 3 G3

This version keeps the existing Student academic workspace (Notes, Assignments, Focus Zone, timetable, attendance and profile) and adds a Teacher workspace.

## Roles
- Student: Dashboard, Timetable, Attendance, Assignments, Notes, Focus Zone, Profile
- Teacher: Dashboard, Timetable, Attendance Management, Students, Profile
- No Admin flow is included.

## Timetable
The CSE 3 G3 timetable is transcribed from the supplied timetable image and shared by both Student and Teacher views.

## Attendance
Attendance is intentionally not fabricated. A teacher records each class/date in `localStorage` under `campusHubAttendance`. Student attendance percentages are calculated from those records. A custom browser event plus the storage event refreshes open views when records change.

## Run
```bash
npm install
npm run dev
```

If an older local copy was used before this version, clear the browser's CampusHub localStorage once so old student/timetable data cannot override the current seed data.
