import { Trash2, ArrowRightCircle } from "lucide-react";

// Props:
//   complaint: { id, category, location, description, status, createdAt }
//   onAdvanceStatus: (complaintId) => void — cycles Pending → In Progress → Resolved
//   onDelete: (complaintId) => void
export default function ComplaintCard({ complaint, onAdvanceStatus, onDelete }) {
  const statusClass =
    complaint.status === "Resolved"
      ? "cl-status--resolved"
      : complaint.status === "In Progress"
      ? "cl-status--progress"
      : "cl-status--pending";

  const isResolved = complaint.status === "Resolved";

  return (
    <div className="cl-card">
      <span className="cl-pin cl-pin--complaint" aria-hidden="true" />
      <span className="cl-tag cl-tag--complaint">{complaint.category}</span>
      <h3>Complaint #{complaint.id}</h3>
      <p className="cl-meta">
        {complaint.location} · Filed {complaint.createdAt}
      </p>
      <p>{complaint.description}</p>

      <div className="cl-card-foot">
        <span className={`cl-status ${statusClass}`}>{complaint.status}</span>

        <div style={{ display: "flex", gap: 6 }}>
          <button
            className="cl-btn cl-btn--ghost"
            onClick={() => onAdvanceStatus(complaint.id)}
            disabled={isResolved}
            title="Demo action: moves the complaint to its next status"
          >
            <ArrowRightCircle size={14} />
            {isResolved ? "Closed" : "Advance"}
          </button>
          <button
            className="cl-btn cl-btn--danger"
            onClick={() => onDelete(complaint.id)}
            title="Remove this complaint"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
