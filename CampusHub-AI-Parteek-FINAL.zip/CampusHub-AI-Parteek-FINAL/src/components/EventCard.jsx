import { Link } from "react-router-dom";
import { CalendarDays, MapPin, CheckCircle2 } from "lucide-react";

// Props:
//   event: { id, title, club, category, date, time, location, seatsLeft }
//   registered: boolean
//   onRegister: (eventId) => void
export default function EventCard({ event, registered, onRegister }) {
  const full = event.seatsLeft === 0;

  return (
    <div className="cl-card">
      <span className="cl-pin cl-pin--event" aria-hidden="true" />
      <span className="cl-tag cl-tag--event">{event.category}</span>
      <h3>{event.title}</h3>
      <p className="cl-meta">
        <CalendarDays size={13} /> {event.date} · {event.time}
      </p>
      <p className="cl-meta">
        <MapPin size={13} /> {event.location}
      </p>
      <p>{event.club}</p>

      <div className="cl-card-foot">
        <Link to={`/events/${event.id}`} className="cl-btn cl-btn--ghost">
          Details
        </Link>

        {registered ? (
          <button className="cl-btn cl-btn--done" disabled>
            <CheckCircle2 size={14} /> Registered
          </button>
        ) : (
          <button
            className="cl-btn"
            onClick={() => onRegister(event.id)}
            disabled={full}
          >
            {full ? "Full" : "Register"}
          </button>
        )}
      </div>
    </div>
  );
}
