import { Link } from "react-router-dom";
import { Users, CheckCircle2 } from "lucide-react";

// Props:
//   club: { id, name, category, tagline, memberCount }
//   joined: boolean — whether the current user has joined this club
//   onJoin: (clubId) => void
export default function ClubCard({ club, joined, onJoin }) {
  return (
    <div className="cl-card">
      <span className="cl-pin cl-pin--club" aria-hidden="true" />
      <span className="cl-tag cl-tag--club">{club.category}</span>
      <h3>{club.name}</h3>
      <p>{club.tagline}</p>
      <p className="cl-meta">
        <Users size={13} /> {club.memberCount} members
      </p>

      <div className="cl-card-foot">
        <Link to={`/clubs/${club.id}`} className="cl-btn cl-btn--ghost">
          View club
        </Link>

        {joined ? (
          <button className="cl-btn cl-btn--done" disabled>
            <CheckCircle2 size={14} /> Joined
          </button>
        ) : (
          <button className="cl-btn" onClick={() => onJoin(club.id)}>
            Join
          </button>
        )}
      </div>
    </div>
  );
}
