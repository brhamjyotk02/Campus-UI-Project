import { useState } from "react";
import Sidebar from "./Sidebar";

export default function CampusLifeLayout({ children, title = "Campus Life" }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="dashboard-layout campus-life-host">
      <Sidebar isOpen={open} onClose={() => setOpen(false)} />
      <main className="dashboard-main campus-life-main">
        <header className="dashboard-topbar">
          <div className="dashboard-title">
            <h1>{title}</h1>
            <p>CampusHub AI · student life & community</p>
          </div>
          <button className="mobile-menu-button" onClick={() => setOpen(true)}>☰</button>
        </header>
        <div className="cl-main">{children}</div>
      </main>
    </div>
  );
}
