import { useState, useRef, useEffect, useCallback } from "react";
import { Send } from "lucide-react";
import { answerFor, SUGGESTED_QUESTIONS } from "../data/assistantData";

export default function CampusAssistant() {
  const [messages, setMessages] = useState([
    {
      role: "bot",
      text: "Hey! Ask me about your next class, attendance, assignments, events, clubs, or complaints — type your own question or tap a suggestion below.",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const logEndRef = useRef(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = useCallback((question) => {
    const trimmed = question.trim();
    if (!trimmed) return;

    setMessages((prev) => [...prev, { role: "user", text: trimmed }]);
    setIsTyping(true);

    // Small delay makes the bot feel like it's "thinking" rather than
    // instantly pattern-matching — purely cosmetic.
    setTimeout(() => {
      const reply = answerFor(trimmed);
      setMessages((prev) => [...prev, { role: "bot", text: reply }]);
      setIsTyping(false);
    }, 500);
  }, []);

  function handleSubmit(e) {
    e.preventDefault();
    sendMessage(inputValue);
    setInputValue("");
  }

  return (
    <>
      <div className="cl-page-head">
        <h1>Campus Assistant</h1>
        <p>Ask anything about your day — it reads straight from your data.</p>
      </div>

      <div className="cl-chat">
        <div className="cl-chat-log">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`cl-bubble ${
                message.role === "user" ? "cl-bubble--user" : "cl-bubble--bot"
              }`}
            >
              {message.text}
            </div>
          ))}

          {isTyping && (
            <div className="cl-typing">
              <span /><span /><span />
            </div>
          )}

          <div ref={logEndRef} />
        </div>

        <div className="cl-chat-suggestions">
          {SUGGESTED_QUESTIONS.map((question) => (
            <button
              key={question}
              className="cl-suggestion-btn"
              onClick={() => sendMessage(question)}
            >
              {question}
            </button>
          ))}
        </div>

        <form className="cl-chat-input-row" onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Type a question..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button
            type="submit"
            className="cl-chat-send"
            disabled={!inputValue.trim()}
            aria-label="Send"
          >
            <Send size={17} />
          </button>
        </form>
      </div>
    </>
  );
}
