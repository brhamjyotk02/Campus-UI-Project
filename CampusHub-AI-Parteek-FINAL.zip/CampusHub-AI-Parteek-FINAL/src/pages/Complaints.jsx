import { useState, useEffect, useMemo } from "react";
import { CheckCircle2 } from "lucide-react";
import ComplaintCard from "../components/ComplaintCard";
import {
  complaintCategories,
  complaintStatuses,
  seedComplaints,
} from "../data/complaintsData";

const COMPLAINTS_KEY = "complaints";

function nextId(existing) {
  const maxNum = existing.reduce((max, c) => {
    const num = parseInt(c.id.replace("C", ""), 10);
    return Number.isNaN(num) ? max : Math.max(max, num);
  }, 0);
  return `C${String(maxNum + 1).padStart(3, "0")}`;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

export default function Complaints() {
  const [complaints, setComplaints] = useState([]);
  const [statusFilter, setStatusFilter] = useState("All");
  const [formData, setFormData] = useState({
    category: complaintCategories[0],
    location: "",
    description: "",
  });
  const [errors, setErrors] = useState({});
  const [justSubmitted, setJustSubmitted] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(COMPLAINTS_KEY);
    if (stored) {
      setComplaints(JSON.parse(stored));
    } else {
      localStorage.setItem(COMPLAINTS_KEY, JSON.stringify(seedComplaints));
      setComplaints(seedComplaints);
    }
  }, []);

  useEffect(() => {
    if (!justSubmitted) return;
    const timer = setTimeout(() => setJustSubmitted(false), 2500);
    return () => clearTimeout(timer);
  }, [justSubmitted]);

  function persist(updated) {
    setComplaints(updated);
    localStorage.setItem(COMPLAINTS_KEY, JSON.stringify(updated));
  }

  function handleChange(field, value) {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }

  function validate() {
    const nextErrors = {};
    if (!formData.location.trim()) {
      nextErrors.location = "Tell us where this is happening.";
    }
    if (!formData.description.trim()) {
      nextErrors.description = "Add a short description.";
    } else if (formData.description.trim().length < 10) {
      nextErrors.description = "Give a bit more detail (10+ characters).";
    }
    return nextErrors;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    const newComplaint = {
      id: nextId(complaints),
      category: formData.category,
      location: formData.location.trim(),
      description: formData.description.trim(),
      status: "Pending",
      createdAt: today(),
    };

    persist([newComplaint, ...complaints]);
    setFormData({
      category: complaintCategories[0],
      location: "",
      description: "",
    });
    setJustSubmitted(true);
  }

  function handleAdvanceStatus(complaintId) {
    const updated = complaints.map((c) => {
      if (c.id !== complaintId) return c;
      const currentIndex = complaintStatuses.indexOf(c.status);
      const nextStatus =
        complaintStatuses[Math.min(currentIndex + 1, complaintStatuses.length - 1)];
      return { ...c, status: nextStatus };
    });
    persist(updated);
  }

  function handleDelete(complaintId) {
    persist(complaints.filter((c) => c.id !== complaintId));
  }

  const stats = useMemo(() => {
    const counts = { Pending: 0, "In Progress": 0, Resolved: 0 };
    complaints.forEach((c) => {
      if (counts[c.status] !== undefined) counts[c.status] += 1;
    });
    return counts;
  }, [complaints]);

  const visibleComplaints = useMemo(() => {
    if (statusFilter === "All") return complaints;
    return complaints.filter((c) => c.status === statusFilter);
  }, [complaints, statusFilter]);

  return (
    <>
      <div className="cl-page-head">
        <h1>Complaints</h1>
        <p>Something not working on campus? Log it here and track the fix.</p>
      </div>

      <div className="cl-stats-row">
        <div className="cl-stat-tile">
          <span className="cl-stat-num">{complaints.length}</span>
          <span className="cl-stat-label">Total filed</span>
        </div>
        <div className="cl-stat-tile">
          <span className="cl-stat-num">{stats.Pending}</span>
          <span className="cl-stat-label">Pending</span>
        </div>
        <div className="cl-stat-tile">
          <span className="cl-stat-num">{stats["In Progress"]}</span>
          <span className="cl-stat-label">In progress</span>
        </div>
        <div className="cl-stat-tile">
          <span className="cl-stat-num">{stats.Resolved}</span>
          <span className="cl-stat-label">Resolved</span>
        </div>
      </div>

      {justSubmitted && (
        <div className="cl-toast">
          <CheckCircle2 size={16} /> Complaint submitted.
        </div>
      )}

      <form className="cl-form" onSubmit={handleSubmit} noValidate>
        <div className="cl-field">
          <label htmlFor="category">Category</label>
          <select
            id="category"
            className="cl-select"
            value={formData.category}
            onChange={(e) => handleChange("category", e.target.value)}
          >
            {complaintCategories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <div className="cl-field">
          <label htmlFor="location">Location</label>
          <input
            id="location"
            className="cl-input"
            type="text"
            placeholder="e.g. Lab 4, Hostel Block C"
            value={formData.location}
            onChange={(e) => handleChange("location", e.target.value)}
          />
          {errors.location && <p className="cl-error">{errors.location}</p>}
        </div>

        <div className="cl-field">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            className="cl-textarea"
            rows={3}
            placeholder="What's going on?"
            value={formData.description}
            onChange={(e) => handleChange("description", e.target.value)}
          />
          {errors.description && (
            <p className="cl-error">{errors.description}</p>
          )}
        </div>

        <button className="cl-btn" type="submit">
          Submit
        </button>
      </form>

      <div className="cl-toolbar">
        <select
          className="cl-select"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="All">All statuses</option>
          {complaintStatuses.map((status) => (
            <option key={status} value={status}>
              {status}
            </option>
          ))}
        </select>
      </div>

      {visibleComplaints.length === 0 ? (
        <p className="cl-empty">No complaints match this filter.</p>
      ) : (
        <div className="cl-grid">
          {visibleComplaints.map((complaint) => (
            <ComplaintCard
              key={complaint.id}
              complaint={complaint}
              onAdvanceStatus={handleAdvanceStatus}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </>
  );
}
