import { useState, useEffect, useMemo } from "react";
import { Search } from "lucide-react";
import EventCard from "../components/EventCard";
import { eventsData } from "../data/eventsData";

const REGISTERED_KEY = "registeredEvents";

export default function Events() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [sortBy, setSortBy] = useState("date");
  const [registeredIds, setRegisteredIds] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem(REGISTERED_KEY);
    if (stored) setRegisteredIds(JSON.parse(stored));
  }, []);

  useEffect(() => {
    localStorage.setItem(REGISTERED_KEY, JSON.stringify(registeredIds));
  }, [registeredIds]);

  function handleRegister(eventId) {
    setRegisteredIds((prev) => [...prev, eventId]);
  }

  const categories = useMemo(
    () => ["All", ...new Set(eventsData.map((e) => e.category))],
    []
  );

  const visibleEvents = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();

    const today = new Date().toISOString().slice(0, 10);
    let result = eventsData.filter((event) => {
      const matchesTerm =
        !term ||
        event.title.toLowerCase().includes(term) ||
        event.club.toLowerCase().includes(term);
      const matchesCategory =
        categoryFilter === "All" || event.category === categoryFilter;
      const isUpcoming = event.date >= today;
      return matchesTerm && matchesCategory && isUpcoming;
    });

    result = [...result].sort((a, b) => {
      if (sortBy === "seats") return b.seatsLeft - a.seatsLeft;
      return new Date(a.date) - new Date(b.date);
    });

    return result;
  }, [searchTerm, categoryFilter, sortBy]);

  return (
    <>
      <div className="cl-page-head">
        <h1>Events</h1>
        <p>
          Everything happening on campus, in one list. You're registered for{" "}
          {registeredIds.length}.
        </p>
      </div>

      <div className="cl-toolbar">
        <div className="cl-search-wrap">
          <Search size={15} />
          <input
            className="cl-input"
            type="text"
            placeholder="Search events by title or club"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <select
          className="cl-select"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>

        <select
          className="cl-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="date">Sort: Soonest</option>
          <option value="seats">Sort: Most seats left</option>
        </select>
      </div>

      {visibleEvents.length === 0 ? (
        <p className="cl-empty">No events match your filters.</p>
      ) : (
        <div className="cl-grid">
          {visibleEvents.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              registered={registeredIds.includes(event.id)}
              onRegister={handleRegister}
            />
          ))}
        </div>
      )}
    </>
  );
}
