import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, CalendarDays, MapPin, CheckCircle2 } from "lucide-react";
import { getEventById } from "../data/eventsData";

const REGISTERED_KEY = "registeredEvents";

export default function EventDetails() {
  const { eventId } = useParams();
  const event = getEventById(eventId);
  const [registered, setRegistered] = useState(false);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(REGISTERED_KEY) || "[]");
    setRegistered(stored.includes(eventId));
  }, [eventId]);

  function handleRegister() {
    const stored = JSON.parse(localStorage.getItem(REGISTERED_KEY) || "[]");
    const updated = [...stored, eventId];
    localStorage.setItem(REGISTERED_KEY, JSON.stringify(updated));
    setRegistered(true);
  }

  if (!event) {
    return (
      <div className="cl-detail">
        <p>We couldn't find that event.</p>
        <Link to="/events" className="cl-back-link">
          <ArrowLeft size={14} /> Back to Events
        </Link>
      </div>
    );
  }

  const full = event.seatsLeft === 0;

  return (
    <>
      <Link to="/events" className="cl-back-link">
        <ArrowLeft size={14} /> Back to Events
      </Link>

      <div className="cl-detail">
        <span className="cl-tag cl-tag--event">{event.category}</span>
        <h2>{event.title}</h2>
        <p className="cl-meta">Hosted by {event.club}</p>
        <p className="cl-meta">
          <CalendarDays size={13} /> {event.date} · {event.time}
        </p>
        <p className="cl-meta">
          <MapPin size={13} /> {event.location}
        </p>
        <p>{event.description}</p>
        <p className="cl-meta">
          {full ? "No seats left" : `${event.seatsLeft} seats left`}
        </p>

        {registered ? (
          <button className="cl-btn cl-btn--done" disabled>
            <CheckCircle2 size={14} /> You're registered
          </button>
        ) : (
          <button className="cl-btn" onClick={handleRegister} disabled={full}>
            {full ? "Event full" : "Register"}
          </button>
        )}
      </div>
    </>
  );
}
