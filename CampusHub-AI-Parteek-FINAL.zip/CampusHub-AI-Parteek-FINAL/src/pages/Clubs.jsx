import { useState, useEffect, useMemo } from "react";
import { Search } from "lucide-react";
import ClubCard from "../components/ClubCard";
import { clubsData } from "../data/clubsData";

const JOINED_KEY = "joinedClubs";

export default function Clubs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name");
  const [joinedClubIds, setJoinedClubIds] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem(JOINED_KEY);
    if (stored) setJoinedClubIds(JSON.parse(stored));
  }, []);

  useEffect(() => {
    localStorage.setItem(JOINED_KEY, JSON.stringify(joinedClubIds));
  }, [joinedClubIds]);

  function handleJoin(clubId) {
    setJoinedClubIds((prev) => [...prev, clubId]);
  }

  const categories = useMemo(
    () => ["All", ...new Set(clubsData.map((c) => c.category))],
    []
  );

  const visibleClubs = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();

    let result = clubsData.filter((club) => {
      const matchesTerm =
        !term ||
        club.name.toLowerCase().includes(term) ||
        club.category.toLowerCase().includes(term);
      const matchesCategory =
        categoryFilter === "All" || club.category === categoryFilter;
      return matchesTerm && matchesCategory;
    });

    result = [...result].sort((a, b) => {
      if (sortBy === "members") return b.memberCount - a.memberCount;
      return a.name.localeCompare(b.name);
    });

    return result;
  }, [searchTerm, categoryFilter, sortBy]);

  return (
    <>
      <div className="cl-page-head">
        <h1>Clubs</h1>
        <p>
          Find your people. Join a club, show up once, decide from there. You've
          joined {joinedClubIds.length} so far.
        </p>
      </div>

      <div className="cl-toolbar">
        <div className="cl-search-wrap">
          <Search size={15} />
          <input
            className="cl-input"
            type="text"
            placeholder="Search clubs by name or category"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <select
          className="cl-select"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>

        <select
          className="cl-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="name">Sort: Name</option>
          <option value="members">Sort: Most members</option>
        </select>
      </div>

      {visibleClubs.length === 0 ? (
        <p className="cl-empty">No clubs match your filters.</p>
      ) : (
        <div className="cl-grid">
          {visibleClubs.map((club) => (
            <ClubCard
              key={club.id}
              club={club}
              joined={joinedClubIds.includes(club.id)}
              onJoin={handleJoin}
            />
          ))}
        </div>
      )}
    </>
  );
}
