import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Users, CheckCircle2 } from "lucide-react";
import { getClubById } from "../data/clubsData";
import { eventsData } from "../data/eventsData";

const JOINED_KEY = "joinedClubs";

export default function ClubDetails() {
  const { clubId } = useParams();
  const club = getClubById(clubId);
  const [joined, setJoined] = useState(false);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(JOINED_KEY) || "[]");
    setJoined(stored.includes(clubId));
  }, [clubId]);

  function handleJoin() {
    const stored = JSON.parse(localStorage.getItem(JOINED_KEY) || "[]");
    const updated = [...stored, clubId];
    localStorage.setItem(JOINED_KEY, JSON.stringify(updated));
    setJoined(true);
  }

  if (!club) {
    return (
      <div className="cl-detail">
        <p>We couldn't find that club.</p>
        <Link to="/clubs" className="cl-back-link">
          <ArrowLeft size={14} /> Back to Clubs
        </Link>
      </div>
    );
  }

  const clubEvents = eventsData.filter((e) => club.events.includes(e.id));

  return (
    <>
      <Link to="/clubs" className="cl-back-link">
        <ArrowLeft size={14} /> Back to Clubs
      </Link>

      <div className="cl-detail">
        <span className="cl-tag cl-tag--club">{club.category}</span>
        <h2>{club.name}</h2>
        <p className="cl-meta">
          <Users size={13} /> {club.memberCount} members
        </p>
        <p>{club.description}</p>

        {joined ? (
          <button className="cl-btn cl-btn--done" disabled>
            <CheckCircle2 size={14} /> You're a member
          </button>
        ) : (
          <button className="cl-btn" onClick={handleJoin}>
            Join {club.name}
          </button>
        )}

        <h3 style={{ marginTop: 28 }}>Members</h3>
        {club.members.length === 0 ? (
          <p className="cl-empty">No members listed yet.</p>
        ) : (
          <ul>
            {club.members.map((member) => (
              <li key={member}>{member}</li>
            ))}
          </ul>
        )}

        <h3>Club events</h3>
        {clubEvents.length === 0 ? (
          <p className="cl-empty">No upcoming events from this club.</p>
        ) : (
          <ul>
            {clubEvents.map((event) => (
              <li key={event.id}>
                <Link to={`/events/${event.id}`}>{event.title}</Link> —{" "}
                {event.date}
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
