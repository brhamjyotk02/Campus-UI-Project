# CampusHub AI — Teacher + Student

This version keeps the existing CampusHub project as the base and adds a syllabus-aligned Student/Teacher academic flow.

## Run
```bash
npm install
npm run dev
```

## Demo accounts
- Student: `student@campushub.local` / `student123`
- Teacher: `teacher@campushub.local` / `teacher123`

You can also register your own Student or Teacher account.

## Attendance demo
1. Log in as Teacher.
2. Open **Attendance Management**.
3. Select a subject and date.
4. Mark students Present/Absent and save.
5. Log in as the relevant Student in the same browser.
6. The Student Attendance page reads the same stored attendance and recalculates the percentage.

The current first-evaluation implementation uses localStorage so it demonstrates React state, effects, routing, forms, role-based access and shared client-side data without introducing an unscheduled backend stack. For a later REST/API evaluation, the attendance service can be replaced with API calls without changing the page flow.

## Timetable subjects
The dashboard/timetable uses the provided CSE 3 G3 reference: DBMS, FEE II, OOP and Discrete, with TG 201 as the classroom reference.
